-- Fund Details View
CREATE OR REPLACE VIEW vw_FundDetails AS
SELECT
    f.FundID,
    f.Name AS FundName,
    ff.Name AS FundFamily,
    ac.Name AS AssetClass,
    le.LEI,
    le.Name AS LegalEntityName,
    f.Domicile,
    f.InceptionDate,
    f.FundType,
    f.Status,
    sc.ShareClassID,
    sc.Name AS ShareClassName,
    sc.ISIN,
    sc.Currency,
    sc.LaunchDate,
    sc.Status AS ShareClassStatus
FROM Fund f
JOIN LegalEntity le ON f.LegalEntityID = le.LegalEntityID
LEFT JOIN FundFamily ff ON f.FundFamilyID = ff.FundFamilyID
LEFT JOIN AssetClass ac ON f.AssetClassID = ac.AssetClassID
LEFT JOIN ShareClass sc ON sc.FundID = f.FundID;

-- LEI Registry View
CREATE OR REPLACE VIEW vw_LEIRegistry AS
SELECT
    le.LEI,
    le.Name,
    le.RegistrationStatus,
    le.EntityType,
    le.Jurisdiction,
    le.RegistrationDate,
    le.ExpiryDate,
    le.ManagingLOU,
    le.ParentLEI,
    le.UltimateParentLEI,
    a.Line1,
    a.City,
    a.Country
FROM LegalEntity le
LEFT JOIN Address a ON le.AddressID = a.AddressID;

-- W8BENE View
CREATE OR REPLACE VIEW vw_W8BENE AS
SELECT
    le.LEI,
    le.Name,
    w.Chapter3Status,
    w.Chapter4Status,
    w.GIIN,
    w.FATCAStatus,
    w.US_TIN,
    w.Foreign_TIN,
    w.DateSigned,
    w.SignedBy
FROM LegalEntity le
JOIN W8BENEInfo w ON le.LegalEntityID = w.LegalEntityID;