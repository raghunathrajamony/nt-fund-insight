-- FundFamily
CREATE OR REPLACE TABLE FundFamily (
    FundFamilyID INTEGER PRIMARY KEY,
    Name VARCHAR NOT NULL,
    Description VARCHAR
);

-- AssetClass
CREATE OR REPLACE TABLE AssetClass (
    AssetClassID INTEGER PRIMARY KEY,
    Name VARCHAR NOT NULL,
    Description VARCHAR
);

-- Address
CREATE OR REPLACE TABLE Address (
    AddressID INTEGER PRIMARY KEY,
    Line1 VARCHAR,
    Line2 VARCHAR,
    City VARCHAR,
    State VARCHAR,
    PostalCode VARCHAR,
    Country VARCHAR
);

-- LegalEntity
CREATE OR REPLACE TABLE LegalEntity (
    LegalEntityID INTEGER PRIMARY KEY,
    LEI VARCHAR UNIQUE NOT NULL,
    Name VARCHAR NOT NULL,
    RegistrationStatus VARCHAR,
    EntityType VARCHAR,
    RegistrationDate DATE,
    ExpiryDate DATE,
    Jurisdiction VARCHAR,
    ManagingLOU VARCHAR,
    ParentLEI VARCHAR,
    UltimateParentLEI VARCHAR,
    AddressID INTEGER
    -- , FOREIGN KEY (AddressID) REFERENCES Address(AddressID)
);

-- Fund
CREATE OR REPLACE TABLE Fund (
    FundID INTEGER PRIMARY KEY,
    LegalEntityID INTEGER,
    FundFamilyID INTEGER,
    AssetClassID INTEGER,
    Name VARCHAR NOT NULL,
    Domicile VARCHAR,
    InceptionDate DATE,
    FundType VARCHAR,
    Status VARCHAR,
    RegistrationNumber VARCHAR,
    TaxID VARCHAR,
    AddressID INTEGER
    -- , FOREIGN KEY (LegalEntityID) REFERENCES LegalEntity(LegalEntityID)
    -- , FOREIGN KEY (FundFamilyID) REFERENCES FundFamily(FundFamilyID)
    -- , FOREIGN KEY (AssetClassID) REFERENCES AssetClass(AssetClassID)
    -- , FOREIGN KEY (AddressID) REFERENCES Address(AddressID)
);

-- ShareClass
CREATE OR REPLACE TABLE ShareClass (
    ShareClassID INTEGER PRIMARY KEY,
    FundID INTEGER,
    Name VARCHAR NOT NULL,
    ISIN VARCHAR UNIQUE,
    Currency VARCHAR,
    LaunchDate DATE,
    Status VARCHAR,
    Hedged BOOLEAN
    -- , FOREIGN KEY (FundID) REFERENCES Fund(FundID)
);

-- W8BENEInfo
CREATE OR REPLACE TABLE W8BENEInfo (
    W8BENEID INTEGER PRIMARY KEY,
    LegalEntityID INTEGER,
    Chapter3Status VARCHAR,
    Chapter4Status VARCHAR,
    GIIN VARCHAR,
    FATCAStatus VARCHAR,
    US_TIN VARCHAR,
    Foreign_TIN VARCHAR,
    DateSigned DATE,
    SignedBy VARCHAR
    -- , FOREIGN KEY (LegalEntityID) REFERENCES LegalEntity(LegalEntityID)
);

-- Identifier
CREATE OR REPLACE TABLE Identifier (
    IdentifierID INTEGER AUTOINCREMENT PRIMARY KEY,
    EntityType VARCHAR,
    EntityID INTEGER,
    IdentifierType VARCHAR,
    IdentifierValue VARCHAR
);

CREATE TABLE SNOWFLAKE_LEARNING_DB.PUBLIC.w8bene_forms (id STRING, data VARIANT);
