TRUNCATE TABLE FundFamily;
TRUNCATE TABLE AssetClass;
TRUNCATE TABLE Address;
TRUNCATE TABLE LegalEntity;
TRUNCATE TABLE Fund;
TRUNCATE TABLE ShareClass;
TRUNCATE TABLE W8BENEInfo;
TRUNCATE TABLE Identifier;


select * from vw_FundDetails;
select * from vw_LEIRegistry;
select * from vw_W8BENE;

