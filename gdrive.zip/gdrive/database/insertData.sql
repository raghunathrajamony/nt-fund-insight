-- FundFamily
INSERT INTO FundFamily (Name, Description) VALUES
('Northern Trust', 'Northern Trust Asset Management'),
('Fidelity', 'Fidelity International'),
('BlackRock', 'BlackRock Asset Management');

-- AssetClass
INSERT INTO AssetClass (Name, Description) VALUES
('Equity', 'Equity funds'),
('Fixed Income', 'Bond funds'),
('Multi-Asset', 'Multi-asset funds'),
('Money Market', 'Money market funds');

-- Address
INSERT INTO Address (Line1, City, Country) VALUES
('50 Bank Street', 'London', 'United Kingdom'),
('4 Cannon Street', 'London', 'United Kingdom'),
('12 Throgmorton Ave', 'London', 'United Kingdom');

-- LegalEntity
INSERT INTO LegalEntity (LEI, Name, RegistrationStatus, EntityType, RegistrationDate, ExpiryDate, Jurisdiction, ManagingLOU, AddressID)
VALUES
('549300CWUTEDC3CFJ739', 'Northern Trust Global Funds PLC', 'Issued', 'Company', '2001-01-01', '2025-01-01', 'Ireland', 'Irish Stock Exchange', 1),
('5493001KJTIIGC8Y1R12', 'Fidelity Funds SICAV', 'Issued', 'Company', '1990-06-01', '2025-06-01', 'Luxembourg', 'LuxCSD', 2),
('5493003MDF9R2W8Y1R11', 'BlackRock Global Funds', 'Issued', 'Company', '1988-03-01', '2025-03-01', 'Luxembourg', 'LuxCSD', 3);

-- Fund
INSERT INTO Fund (LegalEntityID, FundFamilyID, AssetClassID, Name, Domicile, InceptionDate, FundType, Status, RegistrationNumber, TaxID, AddressID)
VALUES
(1, 1, 1, 'NT Global Equity Index Fund', 'Ireland', '2001-02-01', 'UCITS', 'Active', 'IE0001234567', 'IE1234567', 1),
(2, 2, 2, 'Fidelity European Bond Fund', 'Luxembourg', '1995-07-01', 'SICAV', 'Active', 'LU0001234567', 'LU1234567', 2),
(3, 3, 3, 'BlackRock Global Allocation Fund', 'Luxembourg', '1997-04-01', 'SICAV', 'Active', 'LU0009876543', 'LU7654321', 3);

-- ShareClass
INSERT INTO ShareClass (FundID, Name, ISIN, Currency, LaunchDate, Status, Hedged) VALUES
(1, 'NT Global Equity Index Fund - USD Acc', 'IE00B1YZSC51', 'USD', '2001-02-01', 'Active', FALSE),
(1, 'NT Global Equity Index Fund - EUR Acc', 'IE00B1YZSD68', 'EUR', '2001-02-01', 'Active', FALSE),
(2, 'Fidelity European Bond Fund - EUR Acc', 'LU0054237671', 'EUR', '1995-07-01', 'Active', FALSE),
(3, 'BlackRock Global Allocation Fund - USD Acc', 'LU0072462426', 'USD', '1997-04-01', 'Active', FALSE);

-- W8BENEInfo
INSERT INTO W8BENEInfo (LegalEntityID, Chapter3Status, Chapter4Status, GIIN, FATCAStatus, US_TIN, Foreign_TIN, DateSigned, SignedBy)
VALUES
(1, 'Corporation', 'Active NFFE', 'NTGI1234.56789.XY.ZZ', 'Participating', NULL, 'IE1234567', '2024-01-01', 'John Smith'),
(2, 'Corporation', 'Active NFFE', 'FID1234.56789.XY.ZZ', 'Participating', NULL, 'LU1234567', '2024-01-01', 'Jane Doe'),
(3, 'Corporation', 'Active NFFE', 'BLK1234.56789.XY.ZZ', 'Participating', NULL, 'LU7654321', '2024-01-01', 'Alice Brown');

-- Identifier
INSERT INTO Identifier (EntityType, EntityID, IdentifierType, IdentifierValue) VALUES
('LegalEntity', 1, 'LEI', '549300CWUTEDC3CFJ739'),
('LegalEntity', 2, 'LEI', '5493001KJTIIGC8Y1R12'),
('LegalEntity', 3, 'LEI', '5493003MDF9R2W8Y1R11'),
('Fund', 1, 'RegistrationNumber', 'IE0001234567'),
('Fund', 2, 'RegistrationNumber', 'LU0001234567'),
('Fund', 3, 'RegistrationNumber', 'LU0009876543'),
('ShareClass', 1, 'ISIN', 'IE00B1YZSC51'),
('ShareClass', 2, 'ISIN', 'IE00B1YZSD68'),
('ShareClass', 3, 'ISIN', 'LU0054237671'),
('ShareClass', 4, 'ISIN', 'LU0072462426');