import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Paper, Table, TableBody, TableRow, TableCell, CircularProgress, Button
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

type W8BENE = {
  LEI: string;
  Name: string;
  Chapter3Status?: string;
  Chapter4Status?: string;
  GIIN?: string;
  FATCAStatus?: string;
  US_TIN?: string;
  Foreign_TIN?: string;
  DateSigned?: string;
  SignedBy?: string;
};

const W8BENEForm: React.FC = () => {
  const { lei } = useParams<{ lei: string }>();
  const navigate = useNavigate();
  const [details, setDetails] = useState<W8BENE | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    setLoading(true);
    setNotFound(false);
    fetch(`/api/w8bene/${lei}`)
      .then(res => {
        if (res.status === 404) {
          setNotFound(true);
          return null;
        }
        if (!res.ok) throw new Error('Failed to fetch W-8BEN-E details');
        return res.json();
      })
      .then(data => setDetails(data))
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [lei]);

  return (
    <Box sx={{ mt: 4 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate('/')}
        sx={{ mb: 2 }}
      >
        Back to Funds Overview
      </Button>
      {loading ? (
        <CircularProgress />
      ) : notFound ? (
        <Typography>No W-8BEN-E form found for this LEI.</Typography>
      ) : !details ? null : (
        <>
          <Typography variant="h5" gutterBottom>
            W-8BEN-E Details for LEI: {details.LEI}
          </Typography>
          <Paper sx={{ p: 2 }}>
            <Table>
              <TableBody>
                <TableRow><TableCell>Name</TableCell><TableCell>{details.Name}</TableCell></TableRow>
                <TableRow><TableCell>Chapter 3 Status</TableCell><TableCell>{details.Chapter3Status}</TableCell></TableRow>
                <TableRow><TableCell>Chapter 4 Status</TableCell><TableCell>{details.Chapter4Status}</TableCell></TableRow>
                <TableRow><TableCell>GIIN</TableCell><TableCell>{details.GIIN}</TableCell></TableRow>
                <TableRow><TableCell>FATCA Status</TableCell><TableCell>{details.FATCAStatus}</TableCell></TableRow>
                <TableRow><TableCell>US TIN</TableCell><TableCell>{details.US_TIN}</TableCell></TableRow>
                <TableRow><TableCell>Foreign TIN</TableCell><TableCell>{details.Foreign_TIN}</TableCell></TableRow>
                <TableRow><TableCell>Date Signed</TableCell><TableCell>{details.DateSigned}</TableCell></TableRow>
                <TableRow><TableCell>Signed By</TableCell><TableCell>{details.SignedBy}</TableCell></TableRow>
              </TableBody>
            </Table>
          </Paper>
        </>
      )}
    </Box>
  );
};

export default W8BENEForm;