// src/components/GLEIFUpdates.tsx
import React, { useState } from 'react';
import { Paper, Typography, Button, CircularProgress } from '@mui/material';
import axios from 'axios';

const GLEIFUpdates: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleGLEIFUpdate = async () => {
    setLoading(true);
    const res = await axios.get('/api/gleif/update/549300CWUTEDC3CFJ739');
    setData(res.data);
    setLoading(false);
  };

  return (
    <Paper sx={{ p: 2 }}>
      <Typography variant="h6" color="primary" gutterBottom>GLEIF Updates</Typography>
      <Button variant="contained" color="primary" onClick={handleGLEIFUpdate} disabled={loading}>
        {loading ? <CircularProgress size={24} /> : 'Update from GLEIF'}
      </Button>
      {data && (
        <pre style={{ marginTop: 16, background: '#f5f5f5', padding: 16, borderRadius: 4 }}>
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </Paper>
  );
};

export default GLEIFUpdates;