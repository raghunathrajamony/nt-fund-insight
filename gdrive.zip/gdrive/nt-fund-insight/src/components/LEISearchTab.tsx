import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  IconButton,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { useNavigate } from 'react-router-dom';

type LEIRecord = {
  id: string;
  attributes: {
    entity: {
      legalName: { name: string };
      entityStatus: string;
      jurisdiction: string;
      legalForm?: { name: string };
    };
    registration: {
      status: string;
      initialRegistrationDate: string;
      lastUpdateDate: string;
    };
  };
};

const LEISearchTab: React.FC = () => {
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<LEIRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!search.trim()) return;
    setLoading(true);
    setError(null);
    setSearched(true);
    setResults([]);
    try {
      const res = await fetch(
        `https://api.gleif.org/api/v1/lei-records?filter[lei]=${encodeURIComponent(search.trim())}`
      );
      if (!res.ok) throw new Error('Failed to fetch LEI data');
      const json = await res.json();
      setResults(json.data || []);
    } catch (err) {
      setError('Failed to fetch LEI data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ mt: 2 }}>
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Search LEI Records
        </Typography>
        <Box
          component="form"
          onSubmit={handleSearch}
          display="flex"
          alignItems="center"
          gap={2}
        >
          <TextField
            label="Enter LEI code"
            variant="outlined"
            size="small"
            value={search}
            onChange={e => setSearch(e.target.value)}
            sx={{ width: 350 }}
            onKeyDown={e => {
              if (e.key === 'Enter') handleSearch();
            }}
          />
          <IconButton color="primary" onClick={() => handleSearch()}>
            <SearchIcon />
          </IconButton>
        </Box>
      </Paper>
      {loading && (
        <Box display="flex" justifyContent="center" mt={4}>
          <CircularProgress />
        </Box>
      )}
      {error && (
        <Typography color="error" sx={{ mt: 2 }}>
          {error}
        </Typography>
      )}
      {!loading && searched && results.length === 0 && !error && (
        <Typography sx={{ mt: 2 }}>No LEI records found.</Typography>
      )}
      {!loading && results.length > 0 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>LEI</TableCell>
                <TableCell>Legal Name</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Jurisdiction</TableCell>
                <TableCell>Legal Form</TableCell>
                <TableCell>Registration Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {results.map(record => (
                <TableRow key={record.id}>
                  <TableCell>{record.id}</TableCell>
                  <TableCell>{record.attributes.entity.legalName?.name}</TableCell>
                  <TableCell>
                    <Chip
                      label={record.attributes.entity.entityStatus}
                      color={
                        record.attributes.entity.entityStatus === 'ACTIVE'
                          ? 'success'
                          : 'default'
                      }
                      size="small"
                    />
                  </TableCell>
                  <TableCell>{record.attributes.entity.jurisdiction}</TableCell>
                  <TableCell>{record.attributes.entity.legalForm?.name || '-'}</TableCell>
                  <TableCell>
                    <Chip
                      label={record.attributes.registration.status}
                      color={
                        record.attributes.registration.status === 'ISSUED'
                          ? 'success'
                          : 'default'
                      }
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="contained"
                      color="primary"
                      size="small"
                      onClick={() => navigate(`/gleif/${record.id}`)}
                      >
                      View Details
                    </Button>  
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};

export default LEISearchTab;