import React, { useEffect, useState } from 'react';
import {
  Box, Typography, CircularProgress, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, TableSortLabel, TablePagination, TextField, IconButton, Button, Link, Tooltip
} from '@mui/material';
import axios from 'axios';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import DownloadIcon from '@mui/icons-material/Download';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import * as XLSX from 'xlsx';
import { useNavigate } from 'react-router-dom';

type Fund = {
  FundID: number;
  FundFamily: string;
  FundName: string;
  LEI: string;
  Domicile: string;
  Status: string;
};

type ApiResponse = {
  total: number;
  page: number;
  size: number;
  funds: Fund[];
};

const columns = [
  { id: 'FundFamily', label: 'Fund Family' },
  { id: 'FundName', label: 'Fund Name' },
  { id: 'LEI', label: 'LEI' },
  { id: 'Domicile', label: 'Domicile' },
  { id: 'Status', label: 'Status' },
  { id: 'Attachments', label: 'Attachments' },
  { id: 'W8BENE', label: 'W-8BEN-E Form' },
];

const FundOverview: React.FC = () => {
  const navigate = useNavigate();
  const [funds, setFunds] = useState<Fund[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('FundName');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  const fetchFunds = () => {
    setLoading(true);
    axios.get<ApiResponse>('/api/funds/', {
      params: {
        page: page + 1,
        size: rowsPerPage,
        search: search || undefined,
        sort_by: sortBy,
        sort_order: sortOrder,
      }
    })
      .then(res => {
        setFunds(res.data.funds);
        setTotal(res.data.total);
        setError(null);
      })
      .catch(() => {
        setError('Failed to load funds data.');
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchFunds();
    // eslint-disable-next-line
  }, [page, rowsPerPage, sortBy, sortOrder]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(0);
    fetchFunds();
  };

  const handleClearSearch = () => {
    setSearch('');
    setPage(0);
    fetchFunds();
  };

  const handleSort = (columnId: string) => {
    if (sortBy === columnId) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(columnId);
      setSortOrder('asc');
    }
  };

  const handleExportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(funds);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Funds');
    XLSX.writeFile(workbook, 'funds.xlsx');
  };

  return (
    <Box>
      <Box display="flex" alignItems="center" mb={2}>
        <Box component="form" onSubmit={handleSearch} display="flex" alignItems="center" flexGrow={1}>
          <TextField
            label="Search by Fund Family, Fund Name, or LEI"
            variant="outlined"
            size="small"
            value={search}
            onChange={e => setSearch(e.target.value)}
            sx={{ mr: 1, width: 320 }}
            InputProps={{
              endAdornment: search && (
                <IconButton size="small" onClick={handleClearSearch}>
                  <ClearIcon />
                </IconButton>
              ),
            }}
          />
          <IconButton type="submit" color="primary">
            <SearchIcon />
          </IconButton>
        </Box>
        <Button
          variant="outlined"
          startIcon={<DownloadIcon />}
          sx={{ ml: 2 }}
          onClick={handleExportToExcel}
        >
          Export to Excel
        </Button>
      </Box>
      {loading ? (
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
          <CircularProgress />
        </Box>
      ) : error ? (
        <Typography color="error" align="center" sx={{ mt: 2 }}>
          {error}
        </Typography>
      ) : (
        <Paper>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {columns.map(col => (
                    <TableCell key={col.id}>
                      {col.id !== 'Attachments' && col.id !== 'W8BENE' ? (
                        <TableSortLabel
                          active={sortBy === col.id}
                          direction={sortBy === col.id ? sortOrder : 'asc'}
                          onClick={() => handleSort(col.id)}
                        >
                          {col.label}
                        </TableSortLabel>
                      ) : (
                        col.label
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {funds.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={columns.length} align="center">
                      No funds found.
                    </TableCell>
                  </TableRow>
                ) : (
                  funds.map(fund => (
                    <TableRow hover key={fund.FundID}>
                      <TableCell>{fund.FundFamily}</TableCell>
                      <TableCell>
                        <Typography
                          sx={{
                            cursor: 'pointer',
                            textDecoration: 'underline',
                            color: '#fff',
                            '&:hover': { color: '#90caf9' }
                          }}
                          onClick={() => navigate(`/funds/${fund.FundID}`)}
                        >
                          {fund.FundName}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Link
                          sx={{
                            color: '#fff',
                            textDecoration: 'underline',
                            cursor: 'pointer',
                            '&:hover': { color: '#90caf9' }
                          }}
                          onClick={() => navigate(`/lei/${fund.LEI}`)}
                        >
                          {fund.LEI}
                        </Link>
                      </TableCell>
                      <TableCell>{fund.Domicile}</TableCell>
                      <TableCell>{fund.Status}</TableCell>
                      {/* Attachments column with tooltip, no file name displayed */}
                      <TableCell>
                        <Tooltip title="W-8BEN-E 2024.pdf">
                          <IconButton
                            component="a"
                            href="#"
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label="W-8BEN-E Form"
                            sx={{ color: '#E41F26' }}
                          >
                            <PictureAsPdfIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                      {/* W-8BEN-E Form column as a white underlined link */}
                      <TableCell>
                        <Link
                          sx={{
                            color: '#fff',
                            textDecoration: 'underline',
                            cursor: 'pointer',
                            '&:hover': { color: '#90caf9' }
                          }}
                          onClick={() => navigate(`/w8bene/${fund.LEI}`)}
                        >
                          View W-8BEN-E
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div"
            count={total}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
            rowsPerPageOptions={[10, 20, 50]}
          />
        </Paper>
      )}
    </Box>
  );
};

export default FundOverview;