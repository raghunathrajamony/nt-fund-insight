import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Tabs,
  Tab,
  Typography,
  Paper,
  CircularProgress,
  Grid,
  Chip,
  Button,
  Divider,
  Link,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const TAB_LABELS = [
  "Overview",
  "Addresses",
  "Registration",
  "Relationships",
];

const statusColor = (status: string) => {
  switch (status) {
    case "ACTIVE":
      return "#1976d2";
    case "INACTIVE":
      return "#d32f2f";
    case "ISSUED":
      return "#1976d2";
    default:
      return "#757575";
  }
};

type RelatedLEI = {
  lei: string;
  legalName: string;
};

const GLEIFDetails: React.FC = () => {
  const { lei } = useParams<{ lei: string }>();
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // For parent/child relationships
  const [directParent, setDirectParent] = useState<RelatedLEI | null>(null);
  const [ultimateParent, setUltimateParent] = useState<RelatedLEI | null>(null);
  const [directChildren, setDirectChildren] = useState<RelatedLEI[]>([]);
  const [ultimateChildren, setUltimateChildren] = useState<RelatedLEI[]>([]);

  useEffect(() => {
    setLoading(true);
    setData(null);
    setDirectParent(null);
    setUltimateParent(null);
    setDirectChildren([]);
    setUltimateChildren([]);
    fetch(`https://api.gleif.org/api/v1/lei-records/${lei}`)
      .then(res => res.json())
      .then(json => setData(json.data))
      .finally(() => setLoading(false));
  }, [lei]);

  // Fetch parent/child LEIs using the new GLEIF API structure
  useEffect(() => {
    if (!data) return;

    // Direct Parent
    const directParentLink = data.relationships?.['direct-parent']?.links?.['lei-record'];
    if (directParentLink) {
      fetch(directParentLink)
        .then(res => res.json())
        .then(json => {
          setDirectParent({
            lei: json.data.id,
            legalName: json.data.attributes?.entity?.legalName?.name || json.data.id,
          });
        })
        .catch(() => setDirectParent(null));
    }

    // Ultimate Parent
    const ultimateParentLink = data.relationships?.['ultimate-parent']?.links?.['lei-record'];
    if (ultimateParentLink) {
      fetch(ultimateParentLink)
        .then(res => res.json())
        .then(json => {
          setUltimateParent({
            lei: json.data.id,
            legalName: json.data.attributes?.entity?.legalName?.name || json.data.id,
          });
        })
        .catch(() => setUltimateParent(null));
    }

    // Direct Children (array)
    const directChildrenLink = data.relationships?.['direct-children']?.links?.['related'];
    if (directChildrenLink) {
      fetch(directChildrenLink)
        .then(res => res.json())
        .then(json => {
          if (Array.isArray(json.data)) {
            setDirectChildren(
              json.data.map((child: any) => ({
                lei: child.id,
                legalName: child.attributes?.entity?.legalName?.name || child.id,
              }))
            );
          }
        })
        .catch(() => setDirectChildren([]));
    }

    // Ultimate Children (array)
    const ultimateChildrenLink = data.relationships?.['ultimate-children']?.links?.['related'];
    if (ultimateChildrenLink) {
      fetch(ultimateChildrenLink)
        .then(res => res.json())
        .then(json => {
          if (Array.isArray(json.data)) {
            setUltimateChildren(
              json.data.map((child: any) => ({
                lei: child.id,
                legalName: child.attributes?.entity?.legalName?.name || child.id,
              }))
            );
          }
        })
        .catch(() => setUltimateChildren([]));
    }
  }, [data]);

  if (loading) return <Box sx={{ mt: 4, textAlign: 'center' }}><CircularProgress /></Box>;
  if (!data) return <Typography sx={{ mt: 4 }}>No GLEIF LEI data found.</Typography>;

  const attributes = data.attributes || {};
  const entity = attributes.entity || {};
  const registration = attributes.registration || {};

  return (
    <Box sx={{ mt: 4 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate('/')}
        sx={{ mb: 2 }}
        color="primary"
        variant="contained"
      >
        Back to Fund Overview
      </Button>
      <Typography variant="h5" gutterBottom>
        {entity.legalName?.name || "GLEIF LEI Details"}
      </Typography>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        {TAB_LABELS.map(label => <Tab key={label} label={label} />)}
      </Tabs>
      <Paper sx={{ p: 3 }}>
        {/* Overview Tab */}
        {tab === 0 && (
          <Box>
            <Typography variant="h6" gutterBottom>Overview</Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}><b>LEI</b></Grid>
              <Grid item xs={6}>{data.id}</Grid>
              <Grid item xs={6}><b>Legal Name</b></Grid>
              <Grid item xs={6}>{entity.legalName?.name}</Grid>
              <Grid item xs={6}><b>Entity Status</b></Grid>
              <Grid item xs={6}>
                <Chip
                  label={entity.entityStatus}
                  sx={{
                    backgroundColor: statusColor(entity.entityStatus),
                    color: "#fff",
                    fontWeight: "bold",
                  }}
                  size="small"
                  variant="filled"
                />
              </Grid>
              <Grid item xs={6}><b>Entity Type</b></Grid>
              <Grid item xs={6}>{entity.entityCategory}</Grid>
              <Grid item xs={6}><b>Jurisdiction</b></Grid>
              <Grid item xs={6}>{entity.jurisdiction}</Grid>
              <Grid item xs={6}><b>Legal Form</b></Grid>
              <Grid item xs={6}>{entity.legalForm?.name}</Grid>
              <Grid item xs={6}><b>Registered At</b></Grid>
              <Grid item xs={6}>{entity.legalAddress?.addressLines?.join(', ')}</Grid>
              <Grid item xs={6}><b>Registered As</b></Grid>
              <Grid item xs={6}>{entity.legalName?.transliteratedOtherEntityNames?.[0]?.name || '-'}</Grid>
              <Grid item xs={6}><b>Entity Created At</b></Grid>
              <Grid item xs={6}>{entity.legalAddress?.firstAddressLine || '-'}</Grid>
            </Grid>
          </Box>
        )}

        {/* Addresses Tab */}
        {tab === 1 && (
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom>Legal Address</Typography>
              <Divider sx={{ mb: 1 }} />
              <Typography>{entity.legalAddress?.addressLines?.join(', ')}</Typography>
              <Typography>{entity.legalAddress?.city}</Typography>
              <Typography>{entity.legalAddress?.country}</Typography>
              <Typography>{entity.legalAddress?.postalCode}</Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom>Headquarters Address</Typography>
              <Divider sx={{ mb: 1 }} />
              <Typography>{entity.headquartersAddress?.addressLines?.join(', ')}</Typography>
              <Typography>{entity.headquartersAddress?.city}</Typography>
              <Typography>{entity.headquartersAddress?.country}</Typography>
              <Typography>{entity.headquartersAddress?.postalCode}</Typography>
            </Grid>
          </Grid>
        )}

        {/* Registration Tab */}
        {tab === 2 && (
          <Box>
            <Typography variant="h6" gutterBottom>Registration Details</Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}><b>Registration Date</b></Grid>
              <Grid item xs={6}>{registration.initialRegistrationDate}</Grid>
              <Grid item xs={6}><b>Last Update</b></Grid>
              <Grid item xs={6}>{registration.lastUpdateDate}</Grid>
              <Grid item xs={6}><b>Status</b></Grid>
              <Grid item xs={6}>
                <Chip
                  label={registration.status}
                  sx={{
                    backgroundColor: statusColor(registration.status),
                    color: "#fff",
                    fontWeight: "bold",
                  }}
                  size="small"
                  variant="filled"
                />
              </Grid>
              <Grid item xs={6}><b>Next Renewal</b></Grid>
              <Grid item xs={6}>{registration.nextRenewalDate}</Grid>
              <Grid item xs={6}><b>Managing LOU</b></Grid>
              <Grid item xs={6}>{registration.managingLou}</Grid>
            </Grid>
          </Box>
        )}

        {/* Relationships Tab */}
        {tab === 3 && (
          <Box>
            <Typography variant="h6" gutterBottom>Relationships</Typography>
            {/* Parent Relationships */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Parent Relationships</Typography>
              <Typography>
                <b>Direct Parent:</b>{" "}
                {directParent ? (
                  <Link
                    href={`https://search.gleif.org/#/record/${directParent.lei}/record`}
                    target="_blank"
                    rel="noopener"
                    sx={{ color: '#1976d2', fontWeight: 500 }}
                  >
                    {directParent.legalName} ({directParent.lei})
                  </Link>
                ) : (
                  <span>No Direct Parent data</span>
                )}
              </Typography>
              <Typography>
                <b>Ultimate Parent:</b>{" "}
                {ultimateParent ? (
                  <Link
                    href={`https://search.gleif.org/#/record/${ultimateParent.lei}/record`}
                    target="_blank"
                    rel="noopener"
                    sx={{ color: '#1976d2', fontWeight: 500 }}
                  >
                    {ultimateParent.legalName} ({ultimateParent.lei})
                  </Link>
                ) : (
                  <span>No Ultimate Parent data</span>
                )}
              </Typography>
            </Box>
            {/* Children Relationships */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Children Relationships</Typography>
              <Typography>
                <b>Direct Children:</b>{" "}
                {directChildren.length > 0 ? (
                  <ul style={{ margin: 0, paddingLeft: 16 }}>
                    {directChildren.map(child => (
                      <li key={child.lei}>
                        <Link
                          href={`https://search.gleif.org/#/record/${child.lei}/record`}
                          target="_blank"
                          rel="noopener"
                          sx={{ color: '#1976d2', fontWeight: 500 }}
                        >
                          {child.legalName} ({child.lei})
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span>No Direct Children data</span>
                )}
              </Typography>
              <Typography>
                <b>Ultimate Children:</b>{" "}
                {ultimateChildren.length > 0 ? (
                  <ul style={{ margin: 0, paddingLeft: 16 }}>
                    {ultimateChildren.map(child => (
                      <li key={child.lei}>
                        <Link
                          href={`https://search.gleif.org/#/record/${child.lei}/record`}
                          target="_blank"
                          rel="noopener"
                          sx={{ color: '#1976d2', fontWeight: 500 }}
                        >
                          {child.legalName} ({child.lei})
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span>No Ultimate Children data</span>
                )}
              </Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Typography variant="body2" color="text.secondary">
              <b>Note:</b> For full relationship details, you may need to follow the links or use the GLEIF XML Relationship API.
            </Typography>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default GLEIFDetails;