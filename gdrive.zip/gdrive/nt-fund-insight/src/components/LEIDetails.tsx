import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Tabs, Tab, Typography, Paper, Table, TableBody, TableRow, TableCell, CircularProgress, Button
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

type LEIRegistry = {
  LEI: string;
  Name: string;
  RegistrationStatus?: string;
  EntityType?: string;
  Jurisdiction?: string;
  RegistrationDate?: string;
  ExpiryDate?: string;
  ManagingLOU?: string;
  ParentLEI?: string;
  UltimateParentLEI?: string;
  Line1?: string;
  City?: string;
  Country?: string;
};

const tabLabels = ['Overview', 'GLEIF Data', 'History'];

const LEIDetails: React.FC = () => {
  const { lei } = useParams<{ lei: string }>();
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);
  const [details, setDetails] = useState<LEIRegistry | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetch(`/api/lei/${lei}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch LEI details');
        return res.json();
      })
      .then(data => setDetails(data))
      .catch(() => setError('Failed to load LEI details.'))
      .finally(() => setLoading(false));
  }, [lei]);

  if (loading) return <CircularProgress />;
  if (error) return <Typography color="error">{error}</Typography>;
  if (!details) return <Typography>No LEI details found.</Typography>;

  return (
    <Box sx={{ mt: 4 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate('/')}
        sx={{ mb: 2 }}
      >
        Back to Funds Overview
      </Button>
      <Typography variant="h5" gutterBottom>
        LEI Details: {details.LEI}
      </Typography>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        {tabLabels.map(label => <Tab key={label} label={label} />)}
      </Tabs>
      <Paper sx={{ p: 2 }}>
        {tab === 0 && (
          <Table>
            <TableBody>
              <TableRow><TableCell>Name</TableCell><TableCell>{details.Name}</TableCell></TableRow>
              <TableRow><TableCell>Registration Status</TableCell><TableCell>{details.RegistrationStatus}</TableCell></TableRow>
              <TableRow><TableCell>Entity Type</TableCell><TableCell>{details.EntityType}</TableCell></TableRow>
              <TableRow><TableCell>Jurisdiction</TableCell><TableCell>{details.Jurisdiction}</TableCell></TableRow>
              <TableRow><TableCell>Registration Date</TableCell><TableCell>{details.RegistrationDate}</TableCell></TableRow>
              <TableRow><TableCell>Expiry Date</TableCell><TableCell>{details.ExpiryDate}</TableCell></TableRow>
              <TableRow><TableCell>Managing LOU</TableCell><TableCell>{details.ManagingLOU}</TableCell></TableRow>
              <TableRow><TableCell>Parent LEI</TableCell><TableCell>{details.ParentLEI}</TableCell></TableRow>
              <TableRow><TableCell>Ultimate Parent LEI</TableCell><TableCell>{details.UltimateParentLEI}</TableCell></TableRow>
              <TableRow>
                <TableCell>Address</TableCell>
                <TableCell>
                  {[details.Line1, details.City, details.Country].filter(Boolean).join(', ')}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        )}
        {tab === 1 && (
          <Typography>GLEIF Data tab content for {details.LEI} (add more fields as needed).</Typography>
        )}
        {tab === 2 && (
          <Typography>History tab content for {details.LEI} (add more fields as needed).</Typography>
        )}
      </Paper>
    </Box>
  );
};

export default LEIDetails;