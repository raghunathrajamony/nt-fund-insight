import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Paper, Typography, Table, TableBody, TableCell, TableRow, CircularProgress, Box, Button
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

type FundDetail = {
  FundID: number;
  FundName: string;
  FundFamily: string;
  AssetClass: string;
  LEI: string;
  LegalEntityName: string;
  Domicile: string;
  InceptionDate: string;
  FundType: string;
  Status: string;
};

const FundDetails: React.FC = () => {
  const { fundId } = useParams<{ fundId: string }>();
  const navigate = useNavigate();
  const [details, setDetails] = useState<FundDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (fundId) {
      fetch(`/api/funds/${fundId}`)
        .then(res => {
          if (!res.ok) throw new Error('Failed to fetch fund details');
          return res.json();
        })
        .then(data => setDetails(data))
        .finally(() => setLoading(false));
    }
  }, [fundId]);

  if (loading) return <CircularProgress />;
  if (!details) return <Typography>No details found.</Typography>;

  return (
    <Box sx={{ mt: 4 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate('/')}
        sx={{ mb: 2 }}
      >
        Back to Funds Overview
      </Button>
      <Paper sx={{ p: 2 }}>
        <Typography variant="h6" color="primary" gutterBottom>Fund Details</Typography>
        <Table>
          <TableBody>
            <TableRow><TableCell>Fund Name</TableCell><TableCell>{details.FundName}</TableCell></TableRow>
            <TableRow><TableCell>Fund Family</TableCell><TableCell>{details.FundFamily}</TableCell></TableRow>
            <TableRow><TableCell>Asset Class</TableCell><TableCell>{details.AssetClass}</TableCell></TableRow>
            <TableRow><TableCell>LEI</TableCell><TableCell>{details.LEI}</TableCell></TableRow>
            <TableRow><TableCell>Legal Entity</TableCell><TableCell>{details.LegalEntityName}</TableCell></TableRow>
            <TableRow><TableCell>Domicile</TableCell><TableCell>{details.Domicile}</TableCell></TableRow>
            <TableRow><TableCell>Inception Date</TableCell><TableCell>{details.InceptionDate}</TableCell></TableRow>
            <TableRow><TableCell>Fund Type</TableCell><TableCell>{details.FundType}</TableCell></TableRow>
            <TableRow><TableCell>Status</TableCell><TableCell>{details.Status}</TableCell></TableRow>
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default FundDetails;