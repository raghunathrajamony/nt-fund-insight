import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Tabs,
  Tab,
  Typography,
  Paper,
  CircularProgress,
  Grid,
  Chip,
  Button,
  Divider,
  Tooltip,
  Link,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const TAB_LABELS = [
  "Overview",
  "Addresses",
  "Registration",
  "Relationships",
];

const statusColor = (status: string) => {
  switch (status) {
    case "ACTIVE":
      return "#1976d2"; // blue
    case "INACTIVE":
      return "#d32f2f"; // red
    case "ISSUED":
      return "#1976d2"; // blue
    default:
      return "#757575"; // grey
  }
};

const GLEIFDetails: React.FC = () => {
  const { lei } = useParams<{ lei: string }>();
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    setData(null); // Clear previous data on new LEI
    fetch(`https://api.gleif.org/api/v1/lei-records/${lei}`)
      .then(res => res.json())
      .then(json => setData(json.data))
      .finally(() => setLoading(false));
  }, [lei]);

  if (loading) return <Box sx={{ mt: 4, textAlign: 'center' }}><CircularProgress /></Box>;
  if (!data) return <Typography sx={{ mt: 4 }}>No GLEIF LEI data found.</Typography>;

  const attributes = data.attributes || {};
  const entity = attributes.entity || {};
  const registration = attributes.registration || {};
  const relationships = data.relationships || {};

  // Helper to render relationship references
  const renderRelationship = (rel: any, label: string) => {
    if (!rel?.data) return <Typography>No {label} data</Typography>;
    if (Array.isArray(rel.data) && rel.data.length === 0) return <Typography>No {label} data</Typography>;
    if (Array.isArray(rel.data)) {
      return (
        <ul style={{ margin: 0, paddingLeft: 16 }}>
          {rel.data.map((item: any) => (
            <li key={item.id}>
              <Tooltip title={`Type: ${item.type}`}>
                <span>
                  <Link href={`https://search.gleif.org/#/record/${item.id}/record`} target="_blank" rel="noopener">
                    {item.id}
                  </Link>
                </span>
              </Tooltip>
            </li>
          ))}
        </ul>
      );
    }
    // Single relationship
    return (
      <Tooltip title={`Type: ${rel.data.type}`}>
        <span>
          <Link href={`https://search.gleif.org/#/record/${rel.data.id}/record`} target="_blank" rel="noopener">
            {rel.data.id}
          </Link>
        </span>
      </Tooltip>
    );
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => {
          // Go to Fund Overview tab (assumes "/" is Fund Overview)
          navigate("/");
        }}
        sx={{ mb: 2 }}
        color="primary"
        variant="contained"
      >
        Back to Fund Overview
      </Button>
      <Typography variant="h5" gutterBottom>
        {entity.legalName?.name || "GLEIF LEI Details"}
      </Typography>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        {TAB_LABELS.map(label => <Tab key={label} label={label} />)}
      </Tabs>
      <Paper sx={{ p: 3 }}>
        {/* Overview Tab */}
        {tab === 0 && (
          <Box>
            <Typography variant="h6" gutterBottom>Overview</Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}><b>LEI</b></Grid>
              <Grid item xs={6}>{data.id}</Grid>
              <Grid item xs={6}><b>Legal Name</b></Grid>
              <Grid item xs={6}>{entity.legalName?.name}</Grid>
              <Grid item xs={6}><b>Entity Status</b></Grid>
              <Grid item xs={6}>
                <Chip
                  label={entity.entityStatus}
                  sx={{
                    backgroundColor: statusColor(entity.entityStatus),
                    color: "#fff",
                    fontWeight: "bold",
                  }}
                  size="small"
                  variant="filled"
                />
              </Grid>
              <Grid item xs={6}><b>Entity Type</b></Grid>
              <Grid item xs={6}>{entity.entityCategory}</Grid>
              <Grid item xs={6}><b>Jurisdiction</b></Grid>
              <Grid item xs={6}>{entity.jurisdiction}</Grid>
              <Grid item xs={6}><b>Legal Form</b></Grid>
              <Grid item xs={6}>{entity.legalForm?.name}</Grid>
              <Grid item xs={6}><b>Registered At</b></Grid>
              <Grid item xs={6}>{entity.legalAddress?.addressLines?.join(', ')}</Grid>
              <Grid item xs={6}><b>Registered As</b></Grid>
              <Grid item xs={6}>{entity.legalName?.transliteratedOtherEntityNames?.[0]?.name || '-'}</Grid>
              <Grid item xs={6}><b>Entity Created At</b></Grid>
              <Grid item xs={6}>{entity.legalAddress?.firstAddressLine || '-'}</Grid>
            </Grid>
          </Box>
        )}

        {/* Addresses Tab */}
        {tab === 1 && (
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom>Legal Address</Typography>
              <Divider sx={{ mb: 1 }} />
              <Typography>{entity.legalAddress?.addressLines?.join(', ')}</Typography>
              <Typography>{entity.legalAddress?.city}</Typography>
              <Typography>{entity.legalAddress?.country}</Typography>
              <Typography>{entity.legalAddress?.postalCode}</Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="subtitle1" gutterBottom>Headquarters Address</Typography>
              <Divider sx={{ mb: 1 }} />
              <Typography>{entity.headquartersAddress?.addressLines?.join(', ')}</Typography>
              <Typography>{entity.headquartersAddress?.city}</Typography>
              <Typography>{entity.headquartersAddress?.country}</Typography>
              <Typography>{entity.headquartersAddress?.postalCode}</Typography>
            </Grid>
          </Grid>
        )}

        {/* Registration Tab */}
        {tab === 2 && (
          <Box>
            <Typography variant="h6" gutterBottom>Registration Details</Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}><b>Registration Date</b></Grid>
              <Grid item xs={6}>{registration.initialRegistrationDate}</Grid>
              <Grid item xs={6}><b>Last Update</b></Grid>
              <Grid item xs={6}>{registration.lastUpdateDate}</Grid>
              <Grid item xs={6}><b>Status</b></Grid>
              <Grid item xs={6}>
                <Chip
                  label={registration.status}
                  sx={{
                    backgroundColor: statusColor(registration.status),
                    color: "#fff",
                    fontWeight: "bold",
                  }}
                  size="small"
                  variant="filled"
                />
              </Grid>
              <Grid item xs={6}><b>Next Renewal</b></Grid>
              <Grid item xs={6}>{registration.nextRenewalDate}</Grid>
              <Grid item xs={6}><b>Managing LOU</b></Grid>
              <Grid item xs={6}>{registration.managingLou}</Grid>
            </Grid>
          </Box>
        )}

        {/* Relationships Tab */}
        {tab === 3 && (
          <Box>
            <Typography variant="h6" gutterBottom>Relationships</Typography>
            {/* Fund Management Relationships */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Fund Management Relationships</Typography>
              <Typography>
                <b>Fund Manager:</b> {renderRelationship(relationships.fundManager, "Fund Manager")}
              </Typography>
              <Typography>
                <b>Managed Funds:</b> {renderRelationship(relationships.managedFunds, "Managed Funds")}
              </Typography>
            </Box>
            {/* Umbrella Structure Relationships */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Umbrella Structure Relationships</Typography>
              <Typography>
                <b>Umbrella Fund:</b> {renderRelationship(relationships.umbrellaFund, "Umbrella Fund")}
              </Typography>
              <Typography>
                <b>Sub Funds:</b> {renderRelationship(relationships.subFunds, "Sub Funds")}
              </Typography>
            </Box>
            {/* Parent Relationships */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Parent Relationships</Typography>
              <Typography>
                <b>Direct Parent:</b> {renderRelationship(relationships.directParent, "Direct Parent")}
              </Typography>
              <Typography>
                <b>Ultimate Parent:</b> {renderRelationship(relationships.ultimateParent, "Ultimate Parent")}
              </Typography>
            </Box>
            {/* Children Relationships */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1">Children Relationships</Typography>
              <Typography>
                <b>Direct Children:</b> {renderRelationship(relationships.directChildren, "Direct Children")}
              </Typography>
              <Typography>
                <b>Ultimate Children:</b> {renderRelationship(relationships.ultimateChildren, "Ultimate Children")}
              </Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Typography variant="body2" color="text.secondary">
              <b>Note:</b> For full relationship details, you may need to follow the links or use the GLEIF XML Relationship API.
            </Typography>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default GLEIFDetails;