import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline, AppBar, Toolbar, Typography, Container, Box, Tabs, Tab } from '@mui/material';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import theme from './theme';
import FundOverview from './components/FundOverview';
import FundDetails from './components/FundDetails';
import W8BENEForm from './components/W8BENEForm';
//import GLEIFUpdates from './components/GLEIFUpdates';
import LEIDetails from './components/LEIDetails';
import LEISearchTab from './components/LEISearchTab';
import GLEIFDetails from './components/GLEIFDetails';

function a11yProps(index: number) {
  return { id: `nt-tab-${index}`, 'aria-controls': `nt-tabpanel-${index}` };
}

const App: React.FC = () => {
  const [tab, setTab] = React.useState(0);

  const handleTabChange = (_: React.SyntheticEvent, newValue: number) => setTab(newValue);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppBar position="static" elevation={1}>
          <Toolbar>
            <Typography variant="h6" color="inherit" sx={{ flexGrow: 1 }}>
              NT Fund Instrumentation
            </Typography>
          </Toolbar>
        </AppBar>
        <Container maxWidth="lg" sx={{ mt: 4 }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs
              value={tab}
              onChange={handleTabChange}
              aria-label="NT Tabs"
              variant="scrollable"
              scrollButtons="auto"
              sx={{
                '& .MuiTab-root.Mui-selected': {
                  fontWeight: 'bold',
                },
              }}
            >
              <Tab label="Fund Overview" {...a11yProps(0)} />
              <Tab label="LEI Search" {...a11yProps(1)} />
            </Tabs>
          </Box>
          <Routes>
            <Route
              path="/"
              element={
                <>
                  {tab === 0 && <FundOverview />}
                  {tab === 1 && <LEISearchTab />}
                </>
              }
            />
            <Route path="/funds/:fundId" element={<FundDetails />} />
            <Route path="/lei/:lei" element={<LEIDetails />} />
            <Route path="/w8bene/:lei" element={<W8BENEForm />} />
            <Route path="/gleif/:lei" element={<GLEIFDetails />} />
          </Routes>
        </Container>
      </Router>
    </ThemeProvider>
  );
};

export default App;