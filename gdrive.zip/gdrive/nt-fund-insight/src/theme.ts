import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#005446',
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#8DC63F',
    },
    background: {
      default: '#1A2421',
      paper: '#22302B',
    },
    text: {
      primary: '#FFFFFF',
      secondary: '#E5E5E5',
    },
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: '#005446',
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: {
          backgroundColor: '#8DC63F',
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          color: '#E5E5E5',
        },
      },
    },
  },
});

export default theme;