from pydantic import BaseModel
from typing import Optional

class FundDetail(BaseModel):
    FundID: int
    FundName: str
    FundFamily: Optional[str]
    AssetClass: Optional[str]
    LEI: str
    LegalEntityName: str
    Domicile: Optional[str]
    InceptionDate: Optional[str]
    FundType: Optional[str]
    Status: Optional[str]
    ShareClassID: Optional[int]
    ShareClassName: Optional[str]
    ISIN: Optional[str]
    Currency: Optional[str]
    LaunchDate: Optional[str]
    ShareClassStatus: Optional[str]

class LEIRegistry(BaseModel):
    LEI: str
    Name: str
    RegistrationStatus: Optional[str]
    EntityType: Optional[str]
    Jurisdiction: Optional[str]
    RegistrationDate: Optional[str]
    ExpiryDate: Optional[str]
    ManagingLOU: Optional[str]
    ParentLEI: Optional[str]
    UltimateParentLEI: Optional[str]
    Line1: Optional[str]
    City: Optional[str]
    Country: Optional[str]

class W8BENE(BaseModel):
    LEI: str
    Name: str
    Chapter3Status: Optional[str]
    Chapter4Status: Optional[str]
    GIIN: Optional[str]
    FATCAStatus: Optional[str]
    US_TIN: Optional[str]
    Foreign_TIN: Optional[str]
    DateSigned: Optional[str]
    SignedBy: Optional[str]