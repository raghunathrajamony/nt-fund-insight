import snowflake.connector

def get_snowflake_connection():
    conn = snowflake.connector.connect(
        user='RAGHUNATHR_NTAM',
        password='Good@Morning5881',
        account='IKWTALO-EI02394',
        warehouse='COMPUTE_WH',
        database='SNOWFLAKE_LEARNING_DB',
        schema='PUBLIC',
        role = 'ACCOUNTADMIN'
    )
    return conn
