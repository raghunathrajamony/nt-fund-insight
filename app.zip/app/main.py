from fastapi import FastAPI
from app.api import funds, lei, w8bene
from app.api import gleif

app = FastAPI(
    title="Fund Instrumentation API",
    version="1.0.0"
)

app.include_router(funds.router, prefix="/api/funds", tags=["Funds"])
app.include_router(w8bene.router, prefix="/api/w8bene", tags=["W8BENE"])
app.include_router(lei.router, prefix="/api/lei", tags=["LEI Registry"])
app.include_router(gleif.router, prefix="/api/gleif", tags=["GLEIF"])
