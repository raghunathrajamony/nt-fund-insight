from fastapi import APIRouter, HTTPException
from app.db import get_snowflake_connection
from app.models import LEIRegistry

router = APIRouter()

@router.get("/", response_model=list[LEIRegistry])
def list_lei():
    try:
        conn = get_snowflake_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                LEI,
                NAME AS "Name",
                REGISTRATIONSTATUS AS "RegistrationStatus",
                ENTITYTYPE AS "EntityType",
                JURISDICTION AS "Jurisdiction",
                REGISTRATIONDATE AS "RegistrationDate",
                EXPIRYDATE AS "ExpiryDate",
                MANAGINGLOU AS "ManagingLOU",
                PARENTLEI AS "ParentLEI",
                ULTIMATEPARENTLEI AS "UltimateParentLEI",
                LINE1 AS "Line1",
                CITY AS "City",
                COUNTRY AS "Country"
            FROM vw_LEIRegistry
            LIMIT 10
        """)
        columns = [col[0] for col in cur.description]
        rows = cur.fetchall()
        cur.close()
        conn.close()

        def process_row(row):
            d = dict(zip(columns, row))
            if d.get("RegistrationDate") is not None:
                d["RegistrationDate"] = d["RegistrationDate"].isoformat()
            if d.get("ExpiryDate") is not None:
                d["ExpiryDate"] = d["ExpiryDate"].isoformat()
            return d

        return [process_row(row) for row in rows]
    except Exception as e:
        print("API error:", e)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{lei}", response_model=LEIRegistry)
def get_lei_details(lei: str):
    try:
        conn = get_snowflake_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                LEI,
                NAME AS "Name",
                REGISTRATIONSTATUS AS "RegistrationStatus",
                ENTITYTYPE AS "EntityType",
                JURISDICTION AS "Jurisdiction",
                REGISTRATIONDATE AS "RegistrationDate",
                EXPIRYDATE AS "ExpiryDate",
                MANAGINGLOU AS "ManagingLOU",
                PARENTLEI AS "ParentLEI",
                ULTIMATEPARENTLEI AS "UltimateParentLEI",
                LINE1 AS "Line1",
                CITY AS "City",
                COUNTRY AS "Country"
            FROM vw_LEIRegistry
            WHERE LEI = %s
        """, (lei,))
        row = cur.fetchone()
        columns = [col[0] for col in cur.description]
        cur.close()
        conn.close()
        if not row:
            raise HTTPException(status_code=404, detail="LEI not found")
        d = dict(zip(columns, row))
        if d.get("RegistrationDate") is not None:
            d["RegistrationDate"] = d["RegistrationDate"].isoformat()
        if d.get("ExpiryDate") is not None:
            d["ExpiryDate"] = d["ExpiryDate"].isoformat()
        return d
    except Exception as e:
        print("API error:", e)
        raise HTTPException(status_code=500, detail=str(e))