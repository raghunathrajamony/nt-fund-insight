from fastapi import APIRouter
import httpx

router = APIRouter()

@router.get("/update/{lei}")
async def update_gleif(lei: str):
    url = f"https://api.gleif.org/api/v1/lei-records/{lei}"
    async with httpx.AsyncClient() as client:
        resp = await client.get(url)
        data = resp.json()
    # Here you would update your DB with new data if needed
    return data