from fastapi import APIRouter, HTTPException, Query, Path
from app.db import get_snowflake_connection
from app.models import FundDetail
from typing import Optional

router = APIRouter()

@router.get("/", response_model=dict)
def list_funds(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    sort_by: Optional[str] = "FundName",
    sort_order: Optional[str] = "asc"
):
    try:
        offset = (page - 1) * size
        valid_sort_columns = {
            "FundFamily", "FundName", "FundID", "LEI", "Currency", "Status", "LaunchDate", "InceptionDate"
        }
        if sort_by not in valid_sort_columns:
            sort_by = "FundName"
        order = "ASC" if sort_order.lower() == "asc" else "DESC"

        base_query = """
            SELECT
                FUNDID AS "FundID",
                FUNDNAME AS "FundName",
                FUNDFAMILY AS "FundFamily",
                ASSETCLASS AS "AssetClass",
                LEI,
                LEGALENTITYNAME AS "LegalEntityName",
                DOMICILE AS "Domicile",
                INCEPTIONDATE AS "InceptionDate",
                FUNDTYPE AS "FundType",
                STATUS AS "Status",
                SHARECLASSID AS "ShareClassID",
                SHARECLASSNAME AS "ShareClassName",
                ISIN,
                CURRENCY AS "Currency",
                LAUNCHDATE AS "LaunchDate",
                SHARECLASSSTATUS AS "ShareClassStatus"
            FROM vw_FundDetails
        """

        where_clause = ""
        params = []
        if search:
            where_clause = "WHERE FUNDFAMILY ILIKE %s OR FUNDNAME ILIKE %s OR LEI ILIKE %s"
            params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])

        count_query = f"SELECT COUNT(*) FROM vw_FundDetails {where_clause}"
        data_query = f"""{base_query}
            {where_clause}
            ORDER BY "{sort_by}" {order}
            LIMIT %s OFFSET %s
        """

        conn = get_snowflake_connection()
        cur = conn.cursor()
        # Get total count
        cur.execute(count_query, params)
        total = cur.fetchone()[0]
        # Get paginated data
        cur.execute(data_query, params + [size, offset])
        columns = [col[0] for col in cur.description]
        rows = cur.fetchall()
        cur.close()
        conn.close()

        def process_row(row):
            d = dict(zip(columns, row))
            if d.get("InceptionDate") is not None:
                d["InceptionDate"] = d["InceptionDate"].isoformat()
            if d.get("LaunchDate") is not None:
                d["LaunchDate"] = d["LaunchDate"].isoformat()
            return d

        return {
            "total": total,
            "page": page,
            "size": size,
            "funds": [process_row(row) for row in rows]
        }
    except Exception as e:
        print("API error:", e)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{fund_id}", response_model=FundDetail)
def get_fund_detail(fund_id: int = Path(...)):
    try:
        conn = get_snowflake_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                FUNDID AS "FundID",
                FUNDNAME AS "FundName",
                FUNDFAMILY AS "FundFamily",
                ASSETCLASS AS "AssetClass",
                LEI,
                LEGALENTITYNAME AS "LegalEntityName",
                DOMICILE AS "Domicile",
                INCEPTIONDATE AS "InceptionDate",
                FUNDTYPE AS "FundType",
                STATUS AS "Status",
                SHARECLASSID AS "ShareClassID",
                SHARECLASSNAME AS "ShareClassName",
                ISIN,
                CURRENCY AS "Currency",
                LAUNCHDATE AS "LaunchDate",
                SHARECLASSSTATUS AS "ShareClassStatus"
            FROM vw_FundDetails
            WHERE FUNDID = %s
        """, (fund_id,))
        row = cur.fetchone()
        cur.close()
        conn.close()
        if not row:
            raise HTTPException(status_code=404, detail="Fund not found")
        columns = [
            "FundID", "FundName", "FundFamily", "AssetClass", "LEI", "LegalEntityName",
            "Domicile", "InceptionDate", "FundType", "Status", "ShareClassID",
            "ShareClassName", "ISIN", "Currency", "LaunchDate", "ShareClassStatus"
        ]
        d = dict(zip(columns, row))
        if d.get("InceptionDate") is not None:
            d["InceptionDate"] = d["InceptionDate"].isoformat()
        if d.get("LaunchDate") is not None:
            d["LaunchDate"] = d["LaunchDate"].isoformat()
        return d
    except Exception as e:
        print("API error:", e)
        raise HTTPException(status_code=500, detail=str(e))