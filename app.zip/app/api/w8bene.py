from fastapi import APIRouter, HTTPException
from app.db import get_snowflake_connection
from app.models import W8BENE

router = APIRouter()

@router.get("/", response_model=list[W8BENE])
def list_w8bene():
    try:
        conn = get_snowflake_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                LEI,
                NAME AS "Name",
                CHAPTER3STATUS AS "Chapter3Status",
                CHAPTER4STATUS AS "Chapter4Status",
                GIIN,
                FATCASTATUS AS "FATCAStatus",
                US_TIN,
                FOREIGN_TIN AS "Foreign_TIN",
                DATESIGNED AS "DateSigned",
                SIGNEDBY AS "SignedBy"
            FROM vw_W8BENE
            LIMIT 10
        """)
        columns = [col[0] for col in cur.description]
        rows = cur.fetchall()
        cur.close()
        conn.close()

        def process_row(row):
            d = dict(zip(columns, row))
            if d.get("DateSigned") is not None:
                d["DateSigned"] = d["DateSigned"].isoformat()
            return d

        return [process_row(row) for row in rows]
    except Exception as e:
        print("API error:", e)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{lei}", response_model=W8BENE)
def get_w8bene_details(lei: str):
    try:
        conn = get_snowflake_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                LEI,
                NAME AS "Name",
                CHAPTER3STATUS AS "Chapter3Status",
                CHAPTER4STATUS AS "Chapter4Status",
                GIIN,
                FATCASTATUS AS "FATCAStatus",
                US_TIN,
                FOREIGN_TIN AS "Foreign_TIN",
                DATESIGNED AS "DateSigned",
                SIGNEDBY AS "SignedBy"
            FROM vw_W8BENE
            WHERE LEI = %s
        """, (lei,))
        row = cur.fetchone()
        columns = [col[0] for col in cur.description]
        cur.close()
        conn.close()
        if not row:
            raise HTTPException(status_code=404, detail=f"W-8BEN-E form not found for LEI: {lei}")
        d = dict(zip(columns, row))
        if d.get("DateSigned") is not None:
            d["DateSigned"] = d["DateSigned"].isoformat()
        return d
    except HTTPException:
        raise
    except Exception as e:
        print("API error:", e)
        raise HTTPException(status_code=500, detail=str(e))